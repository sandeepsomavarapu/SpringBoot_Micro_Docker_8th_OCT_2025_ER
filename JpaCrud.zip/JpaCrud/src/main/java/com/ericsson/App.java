package com.ericsson;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class App 
{
    public static void main( String[] args )
    {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
        EntityManager em=emf.createEntityManager();
        //persist(),merge(),remove(),find(),createQuery()
        
        em.getTransaction().begin();
        Employee emp=new Employee(123, "suresh", 23200, "admin");
        em.persist(emp);//ORM
        em.getTransaction().commit();
        
        
    }
}
