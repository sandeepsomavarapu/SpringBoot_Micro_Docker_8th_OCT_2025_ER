package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.DeptEmpDTO;
import com.example.demo.dto.EmployeeList;
import com.example.demo.model.Department;
import com.example.demo.repo.DeptRepo;

@Service
public class DeptServiceImpl implements DeptService {
	@Autowired
	DeptRepo repo;
	@Autowired
	RestTemplate template;

	@Override
	public Department saveDepartment(Department department) {
		return repo.save(department);
	}

	@Override
	public List<Department> getDepartment() {
		return repo.findAll();
	}

	@Override
	public DeptEmpDTO getDeptEmployees(int deptno) {
		Optional<Department> optional = repo.findById(deptno);
		if (optional.isPresent()) {
			Department dept = optional.get();
			EmployeeList emps = template.getForObject("http://localhost:8080/emps/getAllByDeptNo/"+deptno, EmployeeList.class);
			DeptEmpDTO deptEmps = new DeptEmpDTO(dept, emps.getEmps());
			return deptEmps;
		}
		return null;
	}

}
