package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.DeptEmpDTO;
import com.example.demo.model.Department;
import com.example.demo.service.DeptService;

@RestController
@RequestMapping("/dept")

public class DeptController {

	@Autowired
	DeptService service;

	@PostMapping("/save")
	public Department saveDept(@RequestBody Department dept) {
		return service.saveDepartment(dept);
	}

	@GetMapping("/getAllDept")
	public List<Department> getAllDept() {
		return service.getDepartment();
	}

	@GetMapping("/getEmpsDept/{deptno}")
	public DeptEmpDTO getEmpsDept(@PathVariable("deptno") int deptno) {
		return service.getDeptEmployees(deptno);
	}

}
