package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.EmpDept;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/emps")
public class EmployeeController {
	@Autowired
	EmployeeService service;

	@PostMapping("/save")
	public String saveEmployee(@RequestBody Employee employee) {
		return service.saveEmployee(employee);
	}

	@GetMapping("/getByEmpId/{eid}")
	public EmpDept getEmployee(@PathVariable("eid") int employeeId) {
		return service.getEmployee(employeeId);
	}
	
	@GetMapping("/getEmpsByDeptId/{did}")
	public List<Employee> getEmployeeByDeptId(@PathVariable("did") int deptId) {
		return service.getEmployeeByDept(deptId);
	}
}
