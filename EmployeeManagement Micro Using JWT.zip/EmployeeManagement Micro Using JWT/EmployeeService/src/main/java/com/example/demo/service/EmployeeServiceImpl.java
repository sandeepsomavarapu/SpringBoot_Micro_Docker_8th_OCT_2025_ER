package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.DeptClient;
import com.example.demo.model.Department;
import com.example.demo.model.EmpDept;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository repo;
	@Autowired
	DeptClient deptClient;
	Logger log = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Override
	public String saveEmployee(Employee employee) {
		repo.save(employee);
		return "Employee Saved!!!";
	}

	@Override
	public EmpDept getEmployee(int employeeId) {
		Optional<Employee> optional = repo.findById(employeeId);
		Employee emp = optional.get();
		log.info("Employee Fecthed :"+emp.getDeptId()+" empid: "+emp.getEmpId());
		Department dept = deptClient.getDepartment(emp.getDeptId());
		log.info("Dept fetched: "+dept.getDeptId()+" "+dept.getDeptName());
		EmpDept empDept = new EmpDept();
		empDept.setEmp(emp);
		empDept.setDept(dept);
		return empDept;
	}

	@Override
	public List<Employee> getEmployeeByDept(int deptId) {

		return repo.findByDeptId(deptId);
	}

}
