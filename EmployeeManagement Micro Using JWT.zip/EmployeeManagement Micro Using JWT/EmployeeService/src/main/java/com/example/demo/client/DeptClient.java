package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.model.Department;
@FeignClient(name = "DEPTSERVICE",path="/dept")
//@FeignClient(value="deptservice" ,url = "http://localhost:8081/dept")
public interface DeptClient {
	@GetMapping("/getByDeptId/{did}")
	public Department getDepartment(@PathVariable("did") int deptId);
}
