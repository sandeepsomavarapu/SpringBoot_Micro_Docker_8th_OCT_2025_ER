package com.example.demo.model;

import java.util.List;

public class DeptEmps {
	private Department dept;
	private List<EmployeeDTO> emps;
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public List<EmployeeDTO> getEmps() {
		return emps;
	}
	public void setEmps(List<EmployeeDTO> emps) {
		this.emps = emps;
	}
	
	
	public DeptEmps(Department dept, List<EmployeeDTO> emps) {
		super();
		this.dept = dept;
		this.emps = emps;
	}
	public DeptEmps() {
		// TODO Auto-generated constructor stub
	}
}
