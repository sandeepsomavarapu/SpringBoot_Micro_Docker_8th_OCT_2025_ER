package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.client.EmpClient;
import com.example.demo.model.Department;
import com.example.demo.model.DeptEmps;
import com.example.demo.model.EmployeeDTO;
import com.example.demo.repo.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired
	DepartmentRepository repo;
	@Autowired
	EmpClient empClient;
	Logger log = LoggerFactory.getLogger(DepartmentServiceImpl.class);
	@Override
	public String saveDepartment(Department dept) {
		repo.save(dept);
		return "Department Saved!!!";
	}
	@Override
	public Department getDepartmentByDeptId(int deptId) {
		Optional<Department> optional = repo.findById(deptId);
		Department dept=optional.get();
		
		return dept;
	}

	@Override
	public DeptEmps getDepartmentAndEmps(int deptId) {
		Optional<Department> optional = repo.findById(deptId);
		Department dept=optional.get();
		List<EmployeeDTO> emps=empClient.getEmpsByDeptId(deptId);
		DeptEmps deptEmps=new DeptEmps();
				deptEmps.setDept(dept);
				deptEmps.setEmps(emps);
		return deptEmps;
	}

}
