package com.example.demo.service;

import com.example.demo.model.Department;
import com.example.demo.model.DeptEmps;

public interface DepartmentService {
	public String saveDepartment(Department dept);

	public DeptEmps getDepartmentAndEmps(int deptId);

	public Department getDepartmentByDeptId(int deptId);
}
