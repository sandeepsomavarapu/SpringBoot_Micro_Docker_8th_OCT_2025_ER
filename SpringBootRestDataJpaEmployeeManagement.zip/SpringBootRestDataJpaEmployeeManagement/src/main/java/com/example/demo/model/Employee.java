package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "employees")
public class Employee {
	@Id
	@Column(name = "eid")
	@GeneratedValue
	private int empId;
	@Column(name = "ename")
	@Size(min = 6,max = 15,message="Name length must between (6,15)")
	@NotNull(message="Name Cannot be null")
	private String empName;
	@Min(value=1000,message="Emp Salary cannot be below 1000")
	@Max(value=100000,message="Emp Salary cannot be above 100000")
	private int empSal;
	@NotEmpty(message="Emp Designation cannot empty or null")
	private String empDesg;

	public Employee() {
		
	}

	public Employee( String empName, int empSal, String empDesg) {
		super();
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}



	public Employee(int empId, String empName, int empSal, String empDesg) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empDesg = empDesg;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empDesg=" + empDesg
				+ "]";
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public String getEmpDesg() {
		return empDesg;
	}

	public void setEmpDesg(String empDesg) {
		this.empDesg = empDesg;
	}

}
