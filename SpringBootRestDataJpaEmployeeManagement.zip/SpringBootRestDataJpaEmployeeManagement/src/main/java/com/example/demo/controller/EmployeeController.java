package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.EmployeeNotFound;
import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/employees") // http://localhost:8080/employees
public class EmployeeController {
	@Autowired
	EmployeeService service;

	@PostMapping("/save") // http://localhost:8080/employees/save
	public String saveEmployee(@RequestBody @Validated Employee employee)// json
	{
		return service.addEmployee(employee);
	}

	@PutMapping("/edit") // http://localhost:8080/employees/edit
	public String editEmployee(@RequestBody Employee employee)// json
	{
		return service.addEmployee(employee);
	}

	@DeleteMapping("/delete/{eid}") // http://localhost:8080/employees/delete/123
	public String editEmployee(@PathVariable("eid") int empId) throws EmployeeNotFound// json
	{
		return service.removeEmployee(empId);
	}

	@GetMapping("/getById/{eid}") // http://localhost:8080/employees/getById/123
	public Employee getEmployee(@PathVariable("eid") int empId) throws EmployeeNotFound// json
	{
		return service.getEmployee(empId);
	}

	@GetMapping("/getAll") // http://localhost:8080/employees/getAll
	public List<Employee> getAllEmployee()// json
	{
		return service.getAllEmployees();
	}

	@GetMapping("/getAllBetween/{intialSal}/{finalSal}") // http://localhost:8080/employees/getAllBetween/1000/2000
	public List<Employee> getAllBetween(@PathVariable("intialSal") int intialSal,
			@PathVariable("finalSal") int finalSal)// json
	{
		return service.getAllBetween(intialSal, finalSal);
	}

	@GetMapping("/getAllByDesg/{desg}") // http://localhost:8080/employees/getAllByDesg/admin
	public List<Employee> getAllByDesg(@PathVariable("desg") String edesg)// json
	{
		return service.getAllByDesg(edesg);
	}

}
