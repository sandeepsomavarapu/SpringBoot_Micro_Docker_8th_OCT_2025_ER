package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/employees")//http://localhost:8080/employees
public class EmployeeController {
	@Autowired
	EmployeeService service;
	
	@PostMapping("/save")//http://localhost:8080/employees/save
	public String saveEmployee(@RequestBody Employee employee)//json
	{
		return service.addEmployee(employee);
	}
	@GetMapping("/getAll")//http://localhost:8080/employees/getAll
	public List<Employee> getAllEmployee()//json
	{
		return service.getAllEmployees();
	}
}
