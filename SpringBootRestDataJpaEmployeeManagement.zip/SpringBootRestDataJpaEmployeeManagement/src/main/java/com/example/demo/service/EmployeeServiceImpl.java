package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.EmployeeNotFound;
import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service("service")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository repo;

	@Override
	public String addEmployee(Employee emp) {
		repo.save(emp);
		return "Employee Saved!!!";// persist
	}

	@Override
	public String updateEmployee(Employee emp) {
		repo.save(emp);
		return "Employee Updated!!!";// merge
	}

	@Override
	public String removeEmployee(int empId) throws EmployeeNotFound {
		
		repo.delete(getEmployee(empId));
		return "Employee Deleted!!";
	}

	@Override
	public Employee getEmployee(int empId) throws EmployeeNotFound {
		Optional<Employee> emp = repo.findById(empId);
		if (emp.isPresent())
			return emp.get();
		else
			throw new EmployeeNotFound("No Employee Found With Given Id :"+empId);
	}

	@Override
	public List<Employee> getAllEmployees() {

		return repo.findAll();
	}

	@Override
	public List<Employee> getAllBetween(int intialSal, int finalSal) {

		return repo.findByEmpSalBetween(intialSal, finalSal);
	}

	@Override
	public List<Employee> getAllByDesg(String empDesg) {

		return repo.findByEmpDesg(empDesg);
	}

}
