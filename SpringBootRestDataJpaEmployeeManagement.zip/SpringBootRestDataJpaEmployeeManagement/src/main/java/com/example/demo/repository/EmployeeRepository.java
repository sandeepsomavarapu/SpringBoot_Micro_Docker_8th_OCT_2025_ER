package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

//	public String addEmployee(Employee emp);//persist-->save
//
//	public String updateEmployee(Employee emp);//merge-->update
//
//	public String removeEmployee(int empId);//remove
//
//	public Employee getEmployee(int empId);//find
//
//	public List<Employee> getAllEmployees();//createQuery
	
//	@Query("select e from Employee e where e.empSal between ?1 and ?2")
//	public List<Employee> getAllBetween(int intialSal, int finalSal);//createQuery
//	
	//@Query("select e from Employee e where e.empDesg=?1")
//	public List<Employee> getAllByDesg(String empDesg);//createQuery
	
	

	public List<Employee> findByEmpSalBetween(int intialSal, int finalSal);//createQuery
	
	public List<Employee> findByEmpDesg(String empDesg);//createQuery
}
