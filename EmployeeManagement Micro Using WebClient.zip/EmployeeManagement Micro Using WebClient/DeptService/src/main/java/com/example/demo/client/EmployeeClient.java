package com.example.demo.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.dto.EmployeeList;

@FeignClient(name = "EmployeeService", url = "http://localhost:8080/emps")

public interface EmployeeClient {
	@GetMapping("/getAllByDeptNo/{deptno}")
	public EmployeeList getEmpsByDeptno(@PathVariable("deptno") int deptno);
}
