package com.ericsson;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
      //loosley coupled
    //IOC  dependency injection	
    	//Product product=new Product();
    	
    	//lazy initializer
    	//Eager Initialize
    	ApplicationContext context=new ClassPathXmlApplicationContext("springconfig.xml");//ctrl+shift+O
    	Product product=context.getBean("pro",Product.class);//dependency injection
      	System.out.println(product);//object address
      	product.setProductName("samasung");
      	System.out.println(product.getProductName());
      	System.out.println(product.getProductCategory());//category address
      	
   
   
    }
}
