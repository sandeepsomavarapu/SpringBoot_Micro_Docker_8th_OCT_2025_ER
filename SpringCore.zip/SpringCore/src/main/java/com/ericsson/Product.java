package com.ericsson;

public class Product {

	private int productId;
	private String productName;
	private int productPrice;
	private Category productCategory;

	public Product() {
		System.out.println("Product Default constructor ...");
	}
	public Product(Category productCategory) {
		super();
		System.out.println("param-constructor of product");
		this.productCategory = productCategory;
	}
	
	
	// setters and getters
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public Category getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(Category productCategory) {
		System.out.println("called category setter....");
		this.productCategory = productCategory;
	}

}
