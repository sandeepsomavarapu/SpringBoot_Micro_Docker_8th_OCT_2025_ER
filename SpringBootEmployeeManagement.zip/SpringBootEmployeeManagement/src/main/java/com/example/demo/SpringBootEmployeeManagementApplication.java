package com.example.demo;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;
import com.example.demo.service.EmployeeServiceImpl;

@SpringBootApplication
public class SpringBootEmployeeManagementApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringBootEmployeeManagementApplication.class, args);
		EmployeeService service = context.getBean("service", EmployeeServiceImpl.class);
		System.out.println(service);
		String empName;
		int empSal;
		String empDesg;
		Scanner scanner = new Scanner(System.in);
		System.out.println("**********Employee Management*************");
		while (true) {
			System.out.println("1.Save Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.Get Employee By Id");
			System.out.println("5.Get All Employees");
			System.out.println("6.Get All Employees Between");
			System.out.println("7.Get By Designation");
			int option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Add Employee Info:");
				System.out.println("Enter your Name");
				empName = scanner.next();
				System.out.println("Enter your Salary");
				empSal = scanner.nextInt();
				System.out.println("Enter your Designation");
				empDesg = scanner.next();
				Employee emp = new Employee(empName, empSal, empDesg);
				System.out.println(service.addEmployee(emp));
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				List<Employee> empoyees = service.getAllEmployees();
				for (Employee employee : empoyees) {
					System.out.println(employee);
				}
				break;
			case 6:
				break;
			case 7:
				break;
			default:

			}

		}
	}
}
