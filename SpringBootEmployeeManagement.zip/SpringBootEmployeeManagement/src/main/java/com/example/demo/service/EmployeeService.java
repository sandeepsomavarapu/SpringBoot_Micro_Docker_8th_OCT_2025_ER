package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Employee;

public interface EmployeeService {
	public String addEmployee(Employee emp);

	public String updateEmployee(Employee emp);

	public String removeEmployee(int empId);

	public Employee getEmployee(int empId);

	public List<Employee> getAllEmployees();

	public List<Employee> getAllBetween(int intialSal, int finalSal);

	public List<Employee> getAllByDesg(String empDesg);
}
