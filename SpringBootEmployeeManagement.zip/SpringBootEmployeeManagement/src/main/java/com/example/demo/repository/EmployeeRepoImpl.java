package com.example.demo.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public class EmployeeRepoImpl implements EmployeeRepository {

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addEmployee(Employee emp) {
		entityManager.persist(emp);
		return "Employee Saved Successfully";
	}

	@Override
	public String updateEmployee(Employee emp) {
		entityManager.merge(emp);
		return "Employee Updated !!!";
	}

	@Override
	public String removeEmployee(int empId) {
		entityManager.remove(getEmployee(empId));
		return "Employee Removed!!!";
	}

	@Override
	public Employee getEmployee(int empId) {

		return entityManager.find(Employee.class, empId);
	}

	@Override
	public List<Employee> getAllEmployees() {
		TypedQuery<Employee> result = entityManager.createQuery("select e from Employee e", Employee.class);
		return result.getResultList();
	}

	@Override
	public List<Employee> getAllBetween(int intialSal, int finalSal) {
		TypedQuery<Employee> result = entityManager
				.createQuery("select e from Employee e where e.empSal between ?1 and ?2", Employee.class);
		result.setParameter(1,intialSal);
		result.setParameter(2,finalSal);
		return result.getResultList();
	}

	@Override
	public List<Employee> getAllByDesg(String empDesg) {
		TypedQuery<Employee> result = entityManager.createQuery("select e from Employee e where e.empDesg=?1",
				Employee.class);
		result.setParameter(1, empDesg);
		return result.getResultList();
	}

}
