package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepoImpl;

@Service("service")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepoImpl repo;

	@Override
	public String addEmployee(Employee emp) {
		return repo.addEmployee(emp);
	}

	@Override
	public String updateEmployee(Employee emp) {

		return repo.updateEmployee(emp);
	}

	@Override
	public String removeEmployee(int empId) {

		return repo.removeEmployee(empId);
	}

	@Override
	public Employee getEmployee(int empId) {

		return repo.getEmployee(empId);
	}

	@Override
	public List<Employee> getAllEmployees() {

		return repo.getAllEmployees();
	}

	@Override
	public List<Employee> getAllBetween(int intialSal, int finalSal) {

		return repo.getAllBetween(intialSal, finalSal);
	}

	@Override
	public List<Employee> getAllByDesg(String empDesg) {

		return repo.getAllByDesg(empDesg);
	}

}
