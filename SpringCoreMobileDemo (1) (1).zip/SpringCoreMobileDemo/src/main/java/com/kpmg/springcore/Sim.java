package com.kpmg.springcore;

public interface Sim {

	void call();
	void browse();
	void sendSms();
	void sendMms();
}
