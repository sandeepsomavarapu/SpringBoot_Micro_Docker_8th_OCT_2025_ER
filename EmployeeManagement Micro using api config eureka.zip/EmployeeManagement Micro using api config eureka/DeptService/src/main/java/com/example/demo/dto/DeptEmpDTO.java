package com.example.demo.dto;

import java.util.List;

import com.example.demo.model.Department;

public class DeptEmpDTO {
	private Department dept;
	private List<Employee> emps;

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public List<Employee> getEmps() {
		return emps;
	}

	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}

	public DeptEmpDTO() {
		// TODO Auto-generated constructor stub
	}

	public DeptEmpDTO(Department dept, List<Employee> emps) {
		super();
		this.dept = dept;
		this.emps = emps;
	}

}
