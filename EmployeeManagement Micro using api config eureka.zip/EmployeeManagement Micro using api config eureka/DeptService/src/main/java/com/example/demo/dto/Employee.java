package com.example.demo.dto;

public class Employee {
	private int empId;
	private String empName;
	private int empSal;
	private int deptno;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empId, String empName, int empSal, int deptno) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.deptno = deptno;
	}
}
