package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dept_info")
public class Department {
	@Id
	private int deptno;
	private String deptName;
	private String deptLocation;

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getDeptLocation() {
		return deptLocation;
	}

	public void setDeptLocation(String deptLocation) {
		this.deptLocation = deptLocation;
	}

	public Department() {
	}

	public Department(int deptno, String deptName, String deptLocation) {
		super();
		this.deptno = deptno;
		this.deptName = deptName;
		this.deptLocation = deptLocation;
	}

}
