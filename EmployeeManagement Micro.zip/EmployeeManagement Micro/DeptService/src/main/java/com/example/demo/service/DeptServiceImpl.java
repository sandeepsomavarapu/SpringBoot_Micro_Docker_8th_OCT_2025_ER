package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.DeptEmpDTO;
import com.example.demo.model.Department;
import com.example.demo.repo.DeptRepo;

@Service
public class DeptServiceImpl implements DeptService {
	@Autowired
	DeptRepo repo;

	@Override
	public Department saveDepartment(Department department) {
		return repo.save(department);
	}

	@Override
	public List<Department> getDepartment() {
		return repo.findAll();
	}

	@Override
	public DeptEmpDTO getDeptEmployees(int deptno) {
	
		return null;
	}

}
