package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.DeptEmpDTO;
import com.example.demo.model.Department;

public interface DeptService {

	public Department saveDepartment(Department department);

	public List<Department> getDepartment();

	public DeptEmpDTO getDeptEmployees(int deptno);

}
